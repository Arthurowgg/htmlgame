GRAND PIXEL GAME LAUNCHER 3.0
=============================

This is a STANDALONE PIXEL DESKTOP APP (not a website).

Linux / macOS:
  ./START.sh

Or:
  python3 -m venv .venv
  .venv/bin/pip install -r launcher/requirements.txt
  .venv/bin/python launcher/run.py

Windows:
  py -3 -m venv .venv
  .venv\Scripts\pip install -r launcher\requirements.txt
  .venv\Scripts\python launcher\run.py

Optional: build a single .exe with
  .venv\Scripts\python launcher\build_exe.py

Controls:
  Enter     Install & Play
  Arrows    Switch version
  1-4       Tabs
  Esc       Quit
