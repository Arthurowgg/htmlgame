#!/usr/bin/env bash
cd "$(dirname "$0")"
if [[ ! -x .venv/bin/python ]]; then
  python3 -m venv .venv
  .venv/bin/pip install -q pygame pillow pywebview
fi
exec .venv/bin/python launcher/run.py "$@"
