@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  py -3 -m venv .venv
  .venv\Scripts\pip install -q pygame pillow pywebview
)
.venv\Scripts\python launcher\run.py %*
